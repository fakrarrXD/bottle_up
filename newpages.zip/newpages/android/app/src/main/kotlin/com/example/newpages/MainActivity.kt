package com.example.newpages

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
